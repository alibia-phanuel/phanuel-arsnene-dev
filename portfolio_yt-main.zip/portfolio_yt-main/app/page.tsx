import React from "react";

const HomePage = () => {
  return <div className="text-6xl text-red-950">HomePage</div>;
};

export default HomePage;
