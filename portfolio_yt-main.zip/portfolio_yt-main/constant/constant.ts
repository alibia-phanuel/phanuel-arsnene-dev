export const NavLinks = [
  {
    id: 1,
    url: "#",
    label: "Home",
  },
  {
    id: 2,
    url: "#",
    label: "Services",
  },
  {
    id: 3,
    url: "#",
    label: "Resume",
  },
  {
    id: 4,
    url: "#",
    label: "Works",
  },
  {
    id: 5,
    url: "#",
    label: "Skills",
  },
  {
    id: 6,
    url: "#",
    label: "Testimonials",
  },
  {
    id: 7,
    url: "#",
    label: "Contact",
  },
];
